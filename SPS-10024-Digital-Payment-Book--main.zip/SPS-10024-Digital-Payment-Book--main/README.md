# SPS-10024-Digital-Payment-Book-
<h1>Digital Payment Book</h1>
<br>
<p>
  Digital Payment book application is designed to maintain customers, payments, and their purchases. A retailer will be an admin of the application and each customer of the retailer’s shop will be the user. Customers can create their account in the payment book app and they will be able to see their purchase history, pending payments, and also if the user is having any doubt or complaint they can contact the retailer by using the contact our service. Admin will maintain data about purchases made by the customers & can see payment details and pending payment of the customers and will send alerts to the customers if there is any due for payment or payment is pending for a long time.
</p>
<br>
<h3>Project Explanation Video Link : </h3> https://youtu.be/NoN7tKCgi5Y 
<br>
<h3>Application Link : </h3> http://dpay.apps.pcfdev.in/intro


